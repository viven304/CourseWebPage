#include <iostream>

using namespace std;

int main()
{
    // Identify the primitive data type that should be used
    // and write function declaration and assignment for it

    // A person's name?



    // A person's age?



    // Bank balance?




    return 0;
}
